#include<bits/stdc++.h>
#define For(i,x,y) for (register int i=(x);i<=(y);i++)
#define FOR(i,x,y) for (register int i=(x);i<(y);i++)
#define Dow(i,x,y) for (register int i=(x);i>=(y);i--)
#define mp make_pair
#define fi first
#define se second
#define pb push_back
#define ep emplace_back
#define siz(x) ((int)(x).size())
#define all(x) (x).begin(),(x).end()
#define fil(a,b) memset((a),(b),sizeof(a))
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pa;
typedef pair<ll,ll> PA;
typedef vector<int> poly;
inline ll read(){
	ll x=0,f=1;char c=getchar();
	while ((c<'0'||c>'9')&&(c!='-')) c=getchar();
	if (c=='-') f=-1,c=getchar();
	while (c>='0'&&c<='9') x=x*10+c-'0',c=getchar();
	return x*f;
}

const int N = 2010;
int n,m,l,wd,flag[N][N],L[N][N],R[N][N],U[N][N],D[N][N];
poly vec[N];

int t[N];
inline void Add(int x,int y){
    for (;x<=2000;x+=x&-x) t[x]+=y;
}
inline int Query(int x){
    int ret=0;
    for (;x;x-=x&-x) ret+=t[x];
    return ret;
}

int main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	n=read(),m=read(),l=read(),wd=read();
	For(i,1,wd){
		int x=read(),y=read();
		flag[x][y]=1;
	}
	For(i,1,n) For(j,1,m){
		if (flag[i][j]) L[i][j]=0,U[i][j]=0;
			else L[i][j]=L[i][j-1]+1,U[i][j]=U[i-1][j]+1;
	}
	Dow(i,n,1) Dow(j,m,1){
		if (flag[i][j]) R[i][j]=0,D[i][j]=0;
			else R[i][j]=R[i][j+1]+1,D[i][j]=D[i+1][j]+1;
	}
	For(i,1,n) For(j,1,m) R[i][j]=min(R[i][j],D[i][j]),L[i][j]=min(L[i][j],U[i][j]);
    ll ans=0;
    For(p,l-m,n-l){
    	For(x,1,n) vec[x].clear(),t[x]=0;
    	Dow(x,n,1){
    		int y=x-p;
    		if (y>m||y<=0) continue;
    		for (auto i:vec[x]) Add(i,-1);
    		if (R[x][y]>=l) ans+=Query(x+R[x][y]-1)-Query(max(x+l-2,0));
    		if (L[x][y]) Add(x,1),vec[max(x-L[x][y],0)].pb(x);
		}
	}
    printf("%lld\n",ans);
}
