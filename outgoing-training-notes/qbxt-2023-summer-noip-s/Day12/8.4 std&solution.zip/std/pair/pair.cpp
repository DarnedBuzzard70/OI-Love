#include<bits/stdc++.h>
#define For(i,x,y) for (int i=(x);i<=(y);i++)
#define FOR(i,x,y) for (int i=(x);i<(y);i++)
#define Dow(i,x,y) for (int i=(x);i>=(y);i--)
#define mp make_pair
#define fi first
#define se second
#define pb push_back
#define ep emplace_back
#define siz(x) ((int)(x).size())
#define all(x) (x).begin(),(x).end()
#define fil(a,b) memset((a),(b),sizeof(a))
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pa;
typedef pair<ll,ll> PA;
typedef vector<int> poly;
inline ll read(){
	ll x=0,f=1;char c=getchar();
	while ((c<'0'||c>'9')&&(c!='-')) c=getchar();
	if (c=='-') f=-1,c=getchar();
	while (c>='0'&&c<='9') x=x*10+c-'0',c=getchar();
	return x*f;
}

const int N = 45, M = 4e6+10;
int n,a[N],pos[N],rpos[N],cnt[N][N];
bool vis[N];

int tot,nxttot;
PA f[M],g[M];
pair<poly,int>now[M],nxt[M];
inline int get(poly v,int tim){
	int ret=v[0];
	FOR(i,1,siz(v)) ret=ret*(cnt[tim][i]+1)+v[i];
	return ret;
}
inline void upd(poly x,PA y,int tim){
	int j=get(x,tim);
//	printf("tim=%d j=%d\n",tim,j);
//	for (auto i:x) printf("%d ",i);
//	puts("");
	if (!g[j].fi&&!g[j].se) g[j]=y,nxt[++nxttot]=mp(x,j);
	else if (y.fi<g[j].fi) g[j]=y;
	else if (y.fi==g[j].fi) g[j].se+=y.se;
}

int main(){
	freopen("pair.in","r",stdin);
	freopen("pair.out","w",stdout);
	n=read();
	For(i,1,n) a[i]=read();
	For(i,1,n){
		vis[a[i]]=1;
		int tot=0;
		For(j,1,n) if (vis[j]&&!vis[j-1]){
			int k=j;
			while (vis[k+1]) ++k;
			cnt[i][tot++]=k-j+1;
		}
	}
	fil(vis,0);
	f[0]=mp(0,1),f[1]=mp(0,1);
	tot=2,now[1]=mp(poly{0},0),now[2]=mp(poly{1},1);
	FOR(i,1,n){
		vis[a[i]]=1,fil(pos,-1),fil(rpos,-1);
		int id=0;
		for (int i=1,j=1;i<=n;i=++j){
			while (i<=n&&!vis[i]) rpos[i]=id,++i;
			if (i>n) break;
			for (j=i;j<n&&vis[j+1];) ++j,pos[j]=id;
			pos[i]=id,id++;
		}
		For(j,1,tot){
			auto S=now[j].fi;
			auto v=f[now[j].se];
			int l=pos[a[i+1]-1],r=pos[a[i+1]+1],p=rpos[a[i+1]];
			poly T=S;
			auto tmp=v;
			if (~l&&~r){
				T[r]=T[l]+T[r];
				T.erase(T.begin()+l);
				upd(T,v,i+1);
				
				T[l]++;
				FOR(j,r,siz(S)) tmp.fi+=S[j];
				upd(T,tmp,i+1);
			} else if (l==-1&&r==-1){
				T.insert(T.begin()+p,0);
				upd(T,v,i+1);

				T[p]++;
				FOR(j,p,siz(S)) tmp.fi+=S[j];
				upd(T,tmp,i+1);
			} else if (~l){
				upd(T,v,i+1);

				T[l]++;
				FOR(j,l+1,siz(S)) tmp.fi+=S[j];
				upd(T,tmp,i+1);
			} else {
				upd(T,v,i+1);

				T[r]++;
				FOR(j,r,siz(S)) tmp.fi+=S[j];
				upd(T,tmp,i+1);
			}
		}
		tot=nxttot,nxttot=0;
		For(j,1,tot){
			now[j]=nxt[j],nxt[j].fi.clear();
			f[now[j].se]=g[now[j].se];
			g[now[j].se]=mp(0,0);
		}
//		printf("tim %d\n",i+1);
//		For(j,1,tot){
//			printf("%d [",now[j].se);
//			for (auto k:now[j].fi) printf(" %d",k);
//			printf("]: %lld %lld\n",f[now[j].se].fi,f[now[j].se].se);
//		}
	}
	For(j,1,n) printf("%lld %lld\n",f[j].fi,f[j].se);
}