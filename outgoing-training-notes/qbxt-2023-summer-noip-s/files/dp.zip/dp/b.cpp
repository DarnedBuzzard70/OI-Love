#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("data.in","r",stdin);
	freopen("b.out","w",stdout);
	int a,b;
	scanf("%d%d",&a,&b);
	int l=-1e9,r=1e9,ans=0;
	while (l<=r){
		int mid=l+r>>1;
		if ((a+b)<=mid) ans=mid,r=mid-1;
			else l=mid+1;
	}
	printf("%d\n",ans);
}