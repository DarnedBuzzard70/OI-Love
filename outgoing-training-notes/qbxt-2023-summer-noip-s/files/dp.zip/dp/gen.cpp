#include<bits/stdc++.h>
#define ll long long
using namespace std;

mt19937_64 rnd(time(0));
inline ll R(ll l,ll r){
	return rnd()%(r-l+1)+l;
}

inline double Rreal(){
	return 1.0*R(0,1e6)/1e6;
}

int main(){
	srand(time(0));
	freopen("data.in","w",stdout);
	printf("%d %d\n",R(-1e7,1e7),R(-1e7,1e7));
}