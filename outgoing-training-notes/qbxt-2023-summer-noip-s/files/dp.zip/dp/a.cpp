#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("data.in","r",stdin);
	freopen("a.out","w",stdout);
	int a,b;
	cin>>a>>b;
	cout<<a+b;
}